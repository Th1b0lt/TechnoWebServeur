package com.uca.dao;

public class AppartementDao {
    
}
