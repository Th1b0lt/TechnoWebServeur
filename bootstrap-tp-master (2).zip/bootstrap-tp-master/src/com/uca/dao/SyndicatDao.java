package com.uca.dao;

public class SyndicatDao {
    
}
