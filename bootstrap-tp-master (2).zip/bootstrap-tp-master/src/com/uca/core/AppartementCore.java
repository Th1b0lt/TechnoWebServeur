package com.uca.core;

public class AppartementCore {
    /* 
    public static ArrayList<AppartementEntity> getAllAppartement() {
        return new AppartementDAO().getAllAppartement();
    }
    */
}
