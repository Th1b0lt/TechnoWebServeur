package com.uca.core;

public class AppartementCore {
    
}
