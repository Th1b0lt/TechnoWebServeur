package com.uca.core;

public class ImmeubleCore {
    
}
