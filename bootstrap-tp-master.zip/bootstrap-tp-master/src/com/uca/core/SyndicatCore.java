package com.uca.core;

public class SyndicatCore {
    
}
