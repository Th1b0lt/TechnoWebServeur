package com.uca.dao;

public class ImmeubleDao {
    
}
